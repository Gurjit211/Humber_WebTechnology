document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('contact-form');
    form.addEventListener('submit', function (event) {
        event.preventDefault();
        const name = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const phone = document.getElementById('phone').value.trim();
        const comment = document.getElementById('comment').value.trim();

        // Check if name, email, and comment are not empty
        if (name === '' || email === '' || comment === '') {
            alert('Please fill in all required fields.');
            return;
        }

        // Check if email is valid
        if (!isValidEmail(email)) {
            alert('Please enter a valid email address.');
            return;
        }

        // Submit the form if all validations pass
        alert('Form submitted successfully!');
        form.reset();
    });

    function isValidEmail(email) {
        // Regular expression for email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
});
